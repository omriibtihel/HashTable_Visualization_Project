package com.example.spring_hashtable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHashtableApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHashtableApplication.class, args);

	}


}
