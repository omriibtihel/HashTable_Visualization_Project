package com.example.spring_hashtable;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface HashtableCellRepository extends JpaRepository<HashtableCellEntity,Integer> {

}
