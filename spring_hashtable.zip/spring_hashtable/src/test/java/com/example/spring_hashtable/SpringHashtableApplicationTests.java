package com.example.spring_hashtable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHashtableApplicationTests {

	@Test
	void contextLoads() {
	}

}
